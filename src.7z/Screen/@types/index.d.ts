type MainNaviParamList = {
    ListView : undefined;
    RegistData : undefined;
    UpdateData : undefined;
};

type AuthNaviParamList = {
    AuthInfoScreen : undefined;
}

type PinNaviParmaList = {
    PinScreen : undefined;
}